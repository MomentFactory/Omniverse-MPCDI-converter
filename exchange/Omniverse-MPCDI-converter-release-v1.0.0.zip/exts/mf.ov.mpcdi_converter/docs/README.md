# MPCDI converter for Omniverse [mf.ov.mpcdi_converter]

An Omniverse extension to convert MPDCI* files to USD.
MPCDI* is a VESA interchange format for videoprojectors technical data. 

MPCDIv2 is under Copyright © 2013 – 2015 Video Electronics Standards Association. All rights reserved.

*Multiple Projection Common Data Interchange